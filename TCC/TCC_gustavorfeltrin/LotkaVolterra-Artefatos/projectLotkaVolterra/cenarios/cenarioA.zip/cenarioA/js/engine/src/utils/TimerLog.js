var TimerLog = new function(){
	
	this.array = [];

	this.register = function(date) {
		this.array.push(date);
	}

	this.print = function() {
		var diff = Math.abs(this.array[0]-this.array[this.array.length-1])/1000;
		diff = StringUtils.replaceAll(""+diff, "\.", ",");
		window.prompt("[TimerLog] " + "Length: " + this.array.length + " Diff: Ctrl + C ", diff)
	}


}