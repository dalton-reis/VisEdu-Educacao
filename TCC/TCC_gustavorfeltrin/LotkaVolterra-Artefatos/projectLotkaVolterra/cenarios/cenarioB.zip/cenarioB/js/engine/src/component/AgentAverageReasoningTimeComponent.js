function AgentAverageReasoningTimeComponent(){}

AgentAverageReasoningTimeComponent.prototype = new Component();

AgentAverageReasoningTimeComponent.prototype.currentAgent = null;
AgentAverageReasoningTimeComponent.prototype.lastUpdate = 0;
AgentAverageReasoningTimeComponent.prototype.reasoningAverage = 0;
AgentAverageReasoningTimeComponent.prototype.agentY = 0;
AgentAverageReasoningTimeComponent.prototype.levelLayer = 0;
AgentAverageReasoningTimeComponent.prototype.overallAverage = 0;
AgentAverageReasoningTimeComponent.prototype.audit = "";

AgentAverageReasoningTimeComponent.prototype.onMouseDown = function(x, y, wich) {
	var point = MouseSystem.getNormalizedCoordinate(x, y);
	var selected = layer.queryGameObjects(point.x, point.y, 5, 5, 20);
	selected = selected[0] || null;
	if ( selected!=null && selected.frustum!=null ) {
		this.currentAgent = selected;
	}

}

AgentAverageReasoningTimeComponent.prototype.onUpdate = function(delta){
	var now = Date.now();
	if((now - this.lastUpdate)/1000 >= 1){
		this.lastUpdate = now;
		if (this.currentAgent!=null) {
			var pvpc = ComponentUtils.getComponent(this.currentAgent.frustum, "PERCEPTION_VISION_PERFORMANCE_COMPONENT");
			this.reasoningAverage = Math.round(pvpc.averageReasoningTime * 10000) / 10000;
			this.agentY = Math.round(this.currentAgent.origin.y * 10000) / 10000;
		}		
		this.overallAverage = this.getOverallAverage();
	}	
}

AgentAverageReasoningTimeComponent.prototype.onRender = function(context){
	var fillStyle = context.fillStyle;
	context.fillStyle = "blue";
	context.font = "bold 20px Arial";
	context.fillText("Reasoning [OA: " + this.overallAverage +", @" + this.agentY + "y: " + this.reasoningAverage + "s ].", 20, 50);
	context.fillStyle = fillStyle;
}

AgentAverageReasoningTimeComponent.prototype.getAgents = function() {
	var layer = Game.scene.listLayers[this.levelLayer];
	var agents = [];
	for(var i in layer.listGameObjects) {
		var go = layer.listGameObjects[i];
		if ( go!=null && go.frustum!=null ) {
			agents.push(go);
		}
	}
	return agents;
}


AgentAverageReasoningTimeComponent.prototype.getOverallAverage = function() {
	var overallAverage = 0;
	var agents = this.getAgents();
	for(var i in agents) {
		var agent = agents[i];
		var vision = agent.frustum;
		if ( vision instanceof PolygonObject ) {
			var pvpc = ComponentUtils.getComponent(vision, "PERCEPTION_VISION_PERFORMANCE_COMPONENT");
			if ( pvpc ) {
				overallAverage += pvpc.averageReasoningTime;				
			}
		}
	}
	overallAverage = overallAverage/agents.length;
	return Math.round(overallAverage * 10000) / 10000;
}

AgentAverageReasoningTimeComponent.prototype.onKeyUp = function(keyCode){
	if(keyCode == 65) {
		var agents = this.getAgents();
		var newAgent = null;
		for(var i in agents) {
			var agent = agents[i];
			if ( this.currentAgent==null ) {
				newAgent = agent;
				break;
			} else {
				var tc = ComponentUtils.getComponent(agent, "TOKEN_COMPONENT");
				if (tc) {
					var token = tc.getToken(); // e.g. PERFORMANCEX
					token = token.split("PERFORMANCE")[1];
					if ( this.agentY < token ) {
						newAgent = agent;
						break;
					}
				}
			}
		}
		if ( newAgent==null ) {
			newAgent = agents[0];
		}
		this.currentAgent = newAgent;
	}
	if ( keyCode == 80 ) {
		window.prompt("Ctrl + C", this.audit);
	}
	if ( keyCode == 83 ) {
		var fps = ComponentUtils.getComponent(Game, "FPS_METER_COMPONENT");
		var art = ComponentUtils.getComponent(Game, "AGENT_AVERAGE_REASONING_TIME_COMPONENT"); 
		this.audit += StringUtils.replaceAll("" + fps.currentFps, ".", ",") + "\t" + StringUtils.replaceAll("" + art.overallAverage, ".", ",") + "\t";		
	}
}

AgentAverageReasoningTimeComponent.prototype.getSystems = function(){
	var systems = new Array();
	systems = ArrayUtils.addElement(systems, MouseSystem.getTag());
	systems = ArrayUtils.addElement(systems, RenderSystem.getTag());
	systems = ArrayUtils.addElement(systems, KeySystem.getTag());
	return systems;
}

AgentAverageReasoningTimeComponent.prototype.getTag = function(){
	return "AGENT_AVERAGE_REASONING_TIME_COMPONENT";
}